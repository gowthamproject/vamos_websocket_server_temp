package com.wipro.vamos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VamosApplicationTests {

	@Test
	void contextLoads() {
	}

}

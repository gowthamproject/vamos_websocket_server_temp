package com.wipro.vamos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VamosApplication {

	public static void main(String[] args) {
		SpringApplication.run(VamosApplication.class, args);
	}

}
